﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Summary description for IDBOperation: Interface for Database Operations
/// </summary>
/// Written by Tanzila
interface IDBOperation
{
    void DBConnect(string cs);
    
}